# ============================================
# config.py - Email & Database Configuration
# ============================================

from urllib.parse import quote_plus

# ---- DATABASE CONFIG ----
DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "database": "world_bank_db",
    "user": "postgres",
    "password": "your_password"  # <-- Your PostgreSQL password
}

DB_URL = f"postgresql://{DB_CONFIG['user']}:{quote_plus(DB_CONFIG['password'])}@{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}"

# ---- EMAIL CONFIG ----
# You need a Gmail App Password, NOT your regular password.
# Steps:
#   1. Go to https://myaccount.google.com/apppasswords
#   2. Generate a new app password for "Mail"
#   3. Copy the 16-character password and paste it below

EMAIL_CONFIG = {
    "sender_email": "your_email@gmail.com",     # <-- Your Gmail
    "sender_password": "xxxx xxxx xxxx xxxx",    # <-- App Password (16 chars)
    "recipients": [
        "recipient1@email.com",                  # <-- Who receives the report
        # "recipient2@email.com",                # Add more if needed
    ],
    "smtp_server": "smtp.gmail.com",
    "smtp_port": 587,
}

# ---- REPORT CONFIG ----
REPORT_CONFIG = {
    "csv_filename": "economic_indicators_report.csv",
    "email_subject": "📊 World Bank Economic Report",
}
