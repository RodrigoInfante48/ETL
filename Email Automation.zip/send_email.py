# ============================================
# send_email.py - SEND EMAIL WITH ATTACHMENT
# ============================================
# Sends an email with a text body and a CSV
# file attached using Gmail SMTP.

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import date
from config import EMAIL_CONFIG, REPORT_CONFIG


def send_email(body, attachment_path):
    """
    Sends an email with:
    - A text body (the report summary)
    - A CSV file attached
    
    Parameters:
        body: str - The email body text
        attachment_path: str - Path to the CSV file to attach
    """
    print("📧 Sending email...")
    
    sender = EMAIL_CONFIG["sender_email"]
    password = EMAIL_CONFIG["sender_password"]
    recipients = EMAIL_CONFIG["recipients"]
    
    # ---- Create the email ----
    msg = MIMEMultipart()
    msg["From"] = sender
    msg["To"] = ", ".join(recipients)
    msg["Subject"] = f"{REPORT_CONFIG['email_subject']} - {date.today()}"
    
    # ---- Add body ----
    msg.attach(MIMEText(body, "plain"))
    
    # ---- Add CSV attachment ----
    try:
        with open(attachment_path, "rb") as file:
            attachment = MIMEBase("application", "octet-stream")
            attachment.set_payload(file.read())
            encoders.encode_base64(attachment)
            attachment.add_header(
                "Content-Disposition",
                f"attachment; filename={REPORT_CONFIG['csv_filename']}"
            )
            msg.attach(attachment)
            print(f"   📎 Attached: {REPORT_CONFIG['csv_filename']}")
    except FileNotFoundError:
        print(f"   ⚠️ CSV file not found: {attachment_path}")
        return False
    
    # ---- Send the email ----
    try:
        server = smtplib.SMTP(
            EMAIL_CONFIG["smtp_server"],
            EMAIL_CONFIG["smtp_port"]
        )
        server.starttls()  # Encrypt the connection
        server.login(sender, password)
        server.send_message(msg)
        server.quit()
        
        print(f"   ✅ Email sent to: {', '.join(recipients)}")
        return True
        
    except smtplib.SMTPAuthenticationError:
        print("   ❌ Authentication failed!")
        print("   💡 Make sure you're using a Gmail App Password, not your regular password")
        print("   💡 Get one at: https://myaccount.google.com/apppasswords")
        return False
    except Exception as e:
        print(f"   ❌ Error sending email: {e}")
        return False


if __name__ == "__main__":
    # Test with a simple message
    test_body = "This is a test email from the automation script."
    test_file = REPORT_CONFIG["csv_filename"]
    send_email(test_body, test_file)
